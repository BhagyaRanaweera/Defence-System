public interface ObseverInterface {
    void setComponents(Component components);
    void setStrenth(int strenth);
    void callbuttonHideer();
    void setarea(String area);
    void callareaInfo();
    void setbmsg(String bmsg);
    void callbrodcast();
    void setMainControllerob(MainController mainControllerob);
}
