public interface Component {
    void buttonHideer(int value);
    void areaInfo(String lblInfo);
    void brodcast(String bmsg);
    void mainConConnecter(MainController mainControllerob);
    String sendmsg();
}
